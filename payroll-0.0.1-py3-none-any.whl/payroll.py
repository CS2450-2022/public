from abc import ABC, abstractmethod
from dataclasses import dataclass
import os, os.path


class Classification(ABC):
    """Employee Type"""

    @abstractmethod
    def compute_pay(self, arg) -> None:
        pass


class PayMethod(ABC):
    # Employee Payment Type
    @abstractmethod
    def pay(self, arg) -> None:
        pass


@dataclass
class Employee:
    """Generic type of employee with must have information"""

    emp_id: str
    first_name: str
    last_name: str
    address: str
    city: str
    state: str
    zipcode: str
    classification: Classification
    pay_method: PayMethod = None
    office_phone: str = None
    personal_phone: str = None
    office_email: str = None
    personal_email: str = None
    DOB: str = None
    SSN: str = None
    title: str = None
    dept: str = None
    start_date: str = None
    end_date: str = None
    employment_status: str = None

    # paymethod: PayMethod

    def issue_payment(emp) -> None:
        """Method used to call pay functions"""
        emp.classification.compute_pay(emp)


# quick setup for paymethod
@dataclass
class Direct(PayMethod):
    # Employee that's paid to direct deposit touting number
    accountNumber: str
    routingNumber: str

    def pay(self, arg) -> None:
        pass


@dataclass
class Mailed(PayMethod):
    # Employee that's paid through check/mail
    # Uses employees address from employee.address

    def pay(self, arg) -> None:
        pass


@dataclass
class Hourly(Classification):
    """Employee that's paid based on number of worked hours."""

    hourlyRate: float
    hoursWorked: float = 0

    def compute_pay(self, arg) -> None:
        file1 = open("paylog.txt", "a")
        file1.write(
            f"Mailing {round(float(self.hourlyRate) * float(self.hoursWorked), 2)} to {arg.first_name} {arg.last_name} at {arg.address} {arg.city} {arg.state} {arg.zipcode} \n"
        )
        file1.close()

        self.hoursWorked = 0  # clearing

    def add_timecard(self, num) -> None:
        self.hoursWorked += num


@dataclass
class Salaried(Classification):
    """Employee that's paid based on a fixed monthly salary."""

    monthlySalary: float

    def compute_pay(self, arg) -> None:
        file1 = open("paylog.txt", "a")  # write mode
        file1.write(
            f"Mailing {round((float(self.monthlySalary)/24), 2)} to {arg.first_name} {arg.last_name} at {arg.address} {arg.city} {arg.state} {arg.zipcode} \n"
        )
        file1.close()


@dataclass
class Commissioned(Salaried):
    """Employee that's paid off of Salary, but also receive an additional payment of their total sales times their commission rate."""

    commissionRate: float
    totalSales: float = 0

    def compute_pay(self, arg) -> None:
        file1 = open("paylog.txt", "a")
        file1.write(
            f"Mailing {round((float(self.monthlySalary)/24) + (float((int(self.commissionRate))/100) * self.totalSales), 2)} to {arg.first_name} {arg.last_name} at {arg.address} {arg.city} {arg.state} {arg.zipcode} \n"
        )
        file1.close()

        self.totalSales = 0  # clearing

    def add_receipt(self, num) -> None:
        self.totalSales += num


class Company:
    """Represents a company with employees."""

    def __init__(self) -> None:
        self.employees: list = []

    def add_employee(self, employee: Employee) -> None:
        """Add an employee to the list of employees."""
        self.employees.append(employee)

    def make_salaried(self, employee: Employee, salary: float = None) -> None:
        """Take given employee and Switch classification, Type of employee to Salary"""
        self.employees[self.employees.index(employee)].classification = Salaried(salary)

    def make_hourly(
        self, employee: Employee, hourly_rate: float, hours_worked: float = 0
    ) -> None:
        """Take given employee and Switch classification, Type of employee to Salary"""
        self.employees[self.employees.index(employee)].classification = Hourly(
            hourly_rate
        )

    def make_commissioned(
        self,
        employee: Employee,
        salary: float,
        commission_rate: float = None,
        total_sales: float = 0,
    ) -> None:
        """Take given employee and Switch classification, Type of employee to Salary"""
        self.employees[self.employees.index(employee)].classification = Commissioned(
            salary, commission_rate, total_sales
        )

    def find_employees_by_id(self, id: str) -> list[Employee]:
        """Find all employees with a given emp_id"""
        return [employee for employee in self.employees if employee.emp_id == id]

    def find_employee_by_id(self, id: str) -> Employee:
        """Find the first employee with a given emp_id"""
        list_emp = [employee for employee in self.employees if employee.emp_id == id]
        if list_emp:
            return list_emp[0]
        else:
            return None

    def find_employees_by_classification(self, classification) -> list[Employee]:
        """Find all employees with a given classification"""
        return [
            employee
            for employee in self.employees
            if isinstance(employee.classification, classification) is True
        ]

    def loadEmployees(self) -> None:
        """Open Employees.csv and read the file into seprate employee instances and load those into the employee list."""
        file1 = open("employees.csv", "r")
        file1.readline()
        line = file1.read()
        line = line.split("\n")

        if not self.employees:
            # checks if the list has employees if it does empty it.
            self.employees.clear()

        for i in range(len(line) - 1):
            person = line[i].split(",")
            if person[7] == "3":
                if person[8] == "1":
                    self.add_employee(
                        Employee(
                            person[0].strip(),
                            person[1],
                            person[2],
                            person[3],
                            person[4],
                            person[5],
                            person[6],
                            Hourly(person[11]),
                            Direct(person[12], person[13]),
                            person[14],
                            person[15],
                            person[16],
                            person[17],
                            person[18],
                            person[19],
                            person[20],
                            person[21],
                            person[22],
                            person[23],
                            person[24],
                        )
                    )
                else:
                    self.add_employee(
                        Employee(
                            person[0].strip(),
                            person[1],
                            person[2],
                            person[3],
                            person[4],
                            person[5],
                            person[6],
                            Hourly(person[11]),
                            Mailed(),
                            person[14],
                            person[15],
                            person[16],
                            person[17],
                            person[18],
                            person[19],
                            person[20],
                            person[21],
                            person[22],
                            person[23],
                            person[24],
                        )
                )
            elif person[7] == "2":
                if person[8] == "1":
                    self.add_employee(
                        Employee(
                            person[0].strip(),
                            person[1],
                            person[2],
                            person[3],
                            person[4],
                            person[5],
                            person[6],
                            Commissioned(person[9], person[10]),
                            Direct(person[12], person[13]),
                            person[14],
                            person[15],
                            person[16],
                            person[17],
                            person[18],
                            person[19],
                            person[20],
                            person[21],
                            person[22],
                            person[23],
                            person[24],
                        )
                    )
                else:
                    self.add_employee(
                        Employee(
                            person[0].strip(),
                            person[1],
                            person[2],
                            person[3],
                            person[4],
                            person[5],
                            person[6],
                            Commissioned(person[9], person[10]),
                            Mailed(),
                            person[14],
                            person[15],
                            person[16],
                            person[17],
                            person[18],
                            person[19],
                            person[20],
                            person[21],
                            person[22],
                            person[23],
                            person[24],
                        )
                    )
            elif person[7] == "1":
                if person[8] == "1":
                    self.add_employee(
                        Employee(
                            person[0].strip(),
                            person[1],
                            person[2],
                            person[3],
                            person[4],
                            person[5],
                            person[6],
                            Salaried(person[9]),
                            Direct(person[12], person[13]),
                            person[14],
                            person[15],
                            person[16],
                            person[17],
                            person[18],
                            person[19],
                            person[20],
                            person[21],
                            person[22],
                            person[23],
                            person[24],
                        )
                    )
                else:
                        self.add_employee(
                        Employee(
                            person[0].strip(),
                            person[1],
                            person[2],
                            person[3],
                            person[4],
                            person[5],
                            person[6],
                            Salaried(person[9]),
                            Mailed(),
                            person[14],
                            person[15],
                            person[16],
                            person[17],
                            person[18],
                            person[19],
                            person[20],
                            person[21],
                            person[22],
                            person[23],
                            person[24],
                        )
                    )

        file1.close()

    def process_timecards(self) -> None:
        """open Timecards.csv and process timecard for each employee contained, than add those hours onto the employee instance of them"""
        file2 = open("timecards.csv", "r")
        times = file2.readline()

        while times != "":
            Hours_worked = 0
            times = times.strip().split(",")
            for i in range(1, len(times)):
                Hours_worked = Hours_worked + float(times[i])

            self.employees[
                self.employees.index(self.find_employee_by_id(times[0]))
            ].classification.hoursWorked = Hours_worked
            times = file2.readline()

        file2.close()

    def process_receipts(self) -> None:
        """open receipts.csv and process sales for each employee contained, than add those sales onto the employee instance of them"""
        file3 = open("receipts.csv", "r")
        times = file3.readline()

        while times != "":
            total_sales = 0
            times = times.strip().split(",")
            for i in range(1, len(times)):
                total_sales = total_sales + float(times[i])

            self.employees[
                self.employees.index(self.find_employee_by_id(times[0]))
            ].classification.totalSales = total_sales
            times = file3.readline()

        file3.close()

    def run_payroll(self) -> None:
        PAY_LOGFILE = "paylog.txt"
        if os.path.exists(PAY_LOGFILE):
            os.remove(PAY_LOGFILE)
        for emp in self.employees:
            emp.issue_payment()

    def pass_emps(self) -> list[Employee]:
        """give the current list of emps"""
        return self.employees
